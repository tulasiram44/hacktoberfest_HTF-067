SAHAYA AI DATASET V2
======================

Synthetic prototype/demo dataset for the Sahaya cooperative workforce platform.

FILES
-----
1. sahaya_service_requests_20000.csv
   20,000 labeled customer requests.
   Includes English, Tanglish and a small Tamil subset.
   Labels: category, service, required_skills, urgency, city, zone.

2. service_requests_train.csv
   16,000 training rows.

3. service_requests_test.csv
   4,000 held-out test rows.

4. sahaya_workers_500.csv
   500 synthetic worker profiles.
   Includes skills, experience, rating, location, availability, workload,
   verification status and completed jobs.

5. sahaya_bookings_history_50000.csv
   50,000 synthetic historical bookings from 2025-01-01 through 2026-12-31.
   Useful for demand forecasting and workload analysis.

6. demand_forecasting_daily_zone_service.csv
   Aggregated completed-booking counts by date, zone and service.
   Convenient input for Prophet or another forecasting model.

IMPORTANT
---------
All records are SYNTHETIC and generated for a hackathon prototype.
Do not describe them as real customer, worker, or field-collected data.

RECOMMENDED PIPELINE
--------------------
Customer text
   -> Gemma: structured service/category/urgency/skills extraction
   -> deterministic matching score:
      skill 35%, distance 20%, availability 15%, rating 15%, workload fairness 15%
   -> best worker
   -> Gemma: human-readable match explanation

Demand forecasting:
   bookings history -> aggregate by date/zone/service -> Prophet -> forecast
   -> workforce allocation recommendation

Dataset version: 2.0
Seed: 42
